<?php

// 1. Declare an array.
// 2. Declare an empty for storing the values.
// 3. Loop the first declared array.
// 4. Push the looped values to the empty array.
// 5. Print the empty array.


//$inputs = [1,2,3];
//$outputs=[];
//for ($i=0; $i<count($inputs)-1; $i++) {
//
//    if ($inputs[$i] <= $inputs[$i + 1]) {
//
//        $a = $inputs[$i];
//        $inputs[$i] = $inputs[$i + 1];
//        $inputs[$i + 1] = $a;
//
//        array_push($outputs, $inputs);
//    }
//}
//    print_r($outputs);
//







