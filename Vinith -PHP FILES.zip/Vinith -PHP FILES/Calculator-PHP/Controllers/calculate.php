<?php

if (!isset($_SESSION['login'])) {
    header('Location: /registration');
}

try{
    if($_POST['first_number'] !="0" || $_POST['second_input'] !="0") {
        $name = $_POST['first_number'];
        $name1 = $_POST['second_input'];
        $select = $_POST['calc'];
    }
    $err ="";
    $err1 = "";
    if($name1){
        $err="Infinity";
        header('/list');
    }
    if($name=="" || $name1 ==""){
        $err1 = "required";
        header('/list');
    }
    if ($select === "+") {
        $result = $name+$name1;

    }
    else if ($select === "-") {

        $result = $name-$name1;


    }
    else if ($select === "*") {

        $result = $name*$name1;


    }
    else if ($select === "/") {

        $result = $name/$name1;
    }
    $ins = $app['db']->query("INSERT INTO calulations(first_input,operator,second_input,result)VALUES('$name','$select','$name1','$result')");

    header('Location: /list');
}
catch(PDOException $e){
    die("connection problem");
}
