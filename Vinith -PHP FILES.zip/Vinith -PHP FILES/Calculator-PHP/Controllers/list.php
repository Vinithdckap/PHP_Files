<?php


if (!isset($_SESSION['login'])) {
    header('Location: /registration');
}

try {
    $statement = ($app['db'])->query("select * from calculations");
    $calc = $statement->fetchAll(PDO::FETCH_OBJ);
} catch (PDOException $e) {
    die("connection problem");
}


require 'Views/list.view.php';

