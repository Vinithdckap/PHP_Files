<?php
// is_numeric

// $str1 = "04";
//     $str2 = "08";
//     $str3 = "07-i";

//     $result = is_numeric($str1);
//     echo $result;

//     if(is_numeric($str1) && is_numeric($str2) && is_numeric($str3)){
//         echo "is interger";
//     }
//     else{
//         echo "Is not integer";
//     }




// // var_dump

// $a = 32;
// echo var_dump($a) . "\n";

// $b = "Hello world!";
// echo var_dump($b) . "\n";

// $c = 32.5;
// echo var_dump($c) . "\n";

// $d = array("red", "green", "blue");
// echo var_dump($d) . "\n";

// $e = array(32, "Hello world!", 32.5, array("red", "green", "blue"));
// echo var_dump($e) . "\n";



// // isset

// $a = 0;
// // True because $a is set
// if (is_set($a)) {
//   echo "Variable 'a' is set.\n";
// }
// $b = null;
// // False because $b is NULL
// if (isset($b)) {
//   echo "Variable 'b' is set.";
// }


// // unset;

// $a = "Hello world!";
// echo "The value of variable 'a' before unset: " . $a . "\n";
// unset($a);
// echo "The value of variable 'a' after unset: " . $a;




// // is_null
// $a = 0;
// echo "a is " . is_null($a);
// $b = null;
// echo "b is " . is_null($b);
// $c = "null";
// echo "c is " . is_null($c);
// $d = NULL;
// echo "d is " . is_null($d);



// // empty();
// $empty = "";
// if (empty($empty)) {
//   echo "empty";
// }
// else{
//     echo " not an empty";
// }


// // is_countable

// $a = "Hello";
// echo "a is " . is_countable($a) ;
// $b = array("red", "green", "blue");
// echo "b is " . is_countable($b) ;
// $c = array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");
// echo "c is " . is_countable($c) ;
// $d = [1, 2, 3];
// echo "d is " . is_countable($d) ;



// // is_array

// $a = "Hello";
// echo "a is " . is_array($a) . "\n";

// $b = array("red", "green", "blue");
// echo "b is " . is_array($b) . "\n";

// $c = array("Peter"=>"35", "Ben"=>"37", "Joe"=>"43");
// echo "c is " . is_array($c) . "\n";

// $d = "red, green, blue";
// echo "d is " . is_array($d) . "\n";



// // gettype

// $a = 3;
// echo gettype($a) . "./n";

// $b = 3.2;
// echo gettype($b) . "./n";

// $c = "Hello";
// echo gettype($c) . "./n";

// $d = array();
// echo gettype($d) . "./n";

// $e = array("red", "green", "blue");
// echo gettype($e) . "./n";

// $f = NULL;
// echo gettype($f) . "./n";

// $g = false;
// echo gettype($g) . "./n";



// // invatal

// $a = 32;
// echo intval($a) . ".\n";
// $b = 3.2;
// echo intval($b) . ".\n";
// $c = "32.5";
// echo intval($c) . ".\n";
// $d = array();
// echo intval($d) . ".\n";
// $e = array("red", "green", "blue");
// echo intval($e) . ".\n";


// // is_long

// $a = 32;
// echo "a is " . is_long($a) . ".\n";

// $b = 0;
// echo "b is " . is_long($b) . ".\n";

// $c = 32.5;
// echo "c is " . is_long($c) . ".\n";

// $d = "32";
// echo "d is " . is_long($d) . ".\n";

// $e = true;
// echo "e is " . is_long($e) . ".\n";

// $f = "";
// echo "f is " . is_long($f) . ".\n";



// // strval;

// $a = "Hello";
// echo strval($a) . ".\n";

// $b = "1234.56789";
// echo strval($b) . ".\n";

// $c = "1234.56789Hello";
// echo strval($c) . ".\n";

// $d = "Hello1234.56789";
// echo strval($d) . ".\n";

// $e = 1234;
// echo strval($e) . ".\n";


// // serialize;

//  $data = serialize(array("Red", "Green", "Blue"));
//  echo $data;
//  $test = unserialize($data);
//  var_dump($test);

// // settype


// $a = "32"; // string
// settype($a, "integer"); 

// $b = 32; // integer
// settype($b, "string"); 

// $c = true; // boolean
// settype($c, "integer");


// // var_export
// $a = 32;
// echo var_export($a) . "\n";

// $b = "Hello world!";
// echo var_export($b) . "\n";

// $c = 32.5;
// echo var_export($c) . "\n";

// $d = array("red", "green", "blue");
// echo var_export($d) . "\n";

// $e = array(32, "Hello world!", 32.5, array("red", "green", "blue"));
// echo var_export($e) . "\n";



// // json encode;

// $age = array("Peter"=>35, "Ben"=>37, "Joe"=>43);
// echo json_encode($age);


// // // json decode;

// $jsonobj = '{"Peter":35,"Ben":37,"Joe":43}';
// var_dump(json_decode($jsonobj));



// star using loop;
for($i=0;$i<=5;$i++){        
    for($j=0;$j<=$i;$j++){
        echo "*";
     }
    echo "\n";
}





?>