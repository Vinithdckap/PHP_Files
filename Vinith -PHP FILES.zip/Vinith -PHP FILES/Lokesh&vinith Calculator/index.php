<?php
$history=[];
$count =[];
$arrays = array();
for($x=0;$x<=3;$x++){
    $first = (int)readline('Enter first Operator: ');
    $second = (int)readline('Enter second Operator: ');
    $operand = readline('Which operation which you want you perform (+, -, /)');
  
    if($operand=="+"){
        $result = $first + $second;
        $method = "add";
        array_push($history,$first."".$operand."".$second.""."=".$result);
        array_push($count,$method);
        operations($method,$first,$operand,$second,$result);
}
    if($operand=="-"){
        $result = $first - $second;
        $method = "sub";
        array_push($history,$first."".$operand."".$second.""."=".$result);
        array_push($count,$method);
        operations($method,$first,$operand,$second,$result);
}
    if($operand=="*"){
        $result = $first * $second;
        $method = "mul";
        array_push($history,$first."".$operand."".$second.""."=".$result);
        array_push($count,$method);
        operations($method,$first,$operand,$second,$result);
    }


    if($operand=="/"){
        $result = $first / $second;
        $method = "div";
        array_push($history,$first."".$operand."".$second.""."=".$result);
        array_push($count,$method);
        operations($method,$first,$operand,$second,$result);
}
print_r($history);
print_r(array_count_values($count));
};
function operations($method,$first,$operand,$second,$result){
    global $arrays;
    if (!array_key_exists($method,$arrays)){
       $arrays[$method]=[];
       array_push($arrays[$method],[
            "first"=>$first,
            "Second"=>$second,
            "operator"=>$operand,
            "result"=>$result   
       ]);
    }
    else{
        array_push($arrays[$method],array(
            "first"=>$first,
            "Second"=>$second,
            "operator"=>$operand,
            "result"=>$result
       ));
}
print_r($arrays);
}


































































































// $arraynew = ["jeeva","mhhh"];
// print_r($arraynew);


//$history = [];
//$firstNumber = 4;
//$secondNumber = 4;
//$operator = "+";
//
//switch ($operator) {
//    case "+":
//        $result = $firstNumber + $secondNumber;
//        echo $result;
//        $history["add"] = $firstNumber."".$operator."".$secondNumber.""."=".$result;
//        print_r($history);
//
//        break;
//    case "-":
//        $result = $firstNumber - $secondNumber;
//        echo $result;
//        break;
//    case "":
//        $result = $firstNumber $secondNumber;
//        echo $result;
//        break;
//}

// $method = 'data';



     // $case['add']= array("first"=>$first,"Second"=>$second,"operator"=>$operand,"result"=>$result);
     // array_push($case,array('add'=>array("first"=>$first,"Second"=>$second,"operator"=>$operand,"result"=>$result)));
    // foreach($array as $k => $v) {
    //     $result[$k] = array_count_values($v);
    //     arsort($result[$k]);
    // }
    // print_r($result);


    // print_r($history);
    // print_r(count($history));
    //     }

    // if($operand=="*"){
    // $result = $first * $second;
    // $method = 'mul';
    // $history[]=[
    //     'oper'=>$first."".$operand."".$second.""."=".$result,
    //     ];

    // }



// foreach ($history as $key) {
//     if($key['symbols']=="add"){
//      array_push($arr,$key['symbols']);

//   print_r($arr)."\n";
//     }
// }
// if($operand=="*"){
//     $result = $first * $second;
//     array_push($history, $first."".$operand."".$second.""."=".$result);
//     print_r($history);
// }
// if($operand=="-"){
//     $result = $first - $second;
//     array_push($history, $first."".$operand."".$second.""."=".$result);
//     print_r($history);
// }
// $historyAdd = array();

   // }
        // array_push($arrays['add'],array(
        //     "first"=>$first,
        //     "Second"=>$second,
        //     "operator"=>$operand,
        //     "result"=>$result
            
        // ));
        // array_push($array,array("first"=>$first,"Second"=>$second,"operator"=>$operand,"result"=>$result));














































// switch ($operand) {
//     case "+":
//         $result = $first + $second;
//         $add = $first."".$operand."".$second.""."=".$result;
//         array_push($history, $first."".$operand."".$second.""."=".$result);
//         print_r($history);
//         break;
//     case "-":
//         $result = $first - $second;
//         echo $result;
//         $minus = $first."".$operand."".$second.""."=".$result;
//         array_push($history,$minus);
//         print_r($history);
//         break;
//     case "*":
//         $result = $first*$second;
//         echo $result;
//         break;
// }
























//print_r($history);

// class maths
// {
//     public $number1;
//     public $number2;
//     public $operator;
//     public $history =[];

//     public function calculation($number1,$operator,$number2){

//         if($operator === "+"){
//         print_r($history[]=[
//                 $number1,
//                 $operator,
//                 $number2,
//                 $number1+$number2
    
//             ]);
        
//         }
//         if($operator === "-"){
//             print_r($history[]=[
//                     $number1,
//                     $operator,
//                     $number2,
//                     $number1-$number2
        
//                 ]);
            
//             }
//             if($operator === "*"){
//                 print_r($history[]=[
//                         $number1,
//                         $operator,
//                         $number2,
//                         $number1*$number2
            
//                     ]);
                
//                 }
//     }
  

// }


// // if($operation=="/" && ($fn == 0 || $sn == 0)){
// //     $error = "Never divide any number by zero";
// // }
// // else{
// //     if($operation=="+")
// //         $result=$fn+$sn;
// //     else if($operation=="-")
// //         $result=$fn -$sn;
// //     else if($operation=="x")
// //         $result=$fn*$sn;
// //     else if($operation=="/")
// //         $result=$fn/$sn;
// // }

//     // public function minus()
//     // {
//     //     return $this->number1 - $this->number2."\n";
//     // }

//     // public function divide()
//     // {
//     //     return round($this->number1 / $this->number2,2)."\n";
//     // }

//     // public function __construct($number1,$operator,$number2)
//     // {
//     //     $this->number1= $number1;
//     //     $this->number2= $number2;
//     //     $this->operator = $operator;

//     //     echo $this->add()."\n";
//     //     // echo $this->minus()."\n";
//     //     // echo $this->divide()."\n";
//     // }
// $obj = new maths();
// echo $obj->calculation($first,$operand,$second);

// $first = (int)readline('Enter first Operator: ');
// $second = (int)readline('Enter second Operator: ');
// $operand = readline('Which operation which you want you perform (+, -, /)');
