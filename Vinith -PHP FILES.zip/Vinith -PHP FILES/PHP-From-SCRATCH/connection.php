<?php

try{
    $pdo = new PDO("mysql:host=localhost;dbname=scratch","admin","welcome");
//    echo"hello world";
header("location: ./index.html");
}
catch(PDOException $e){
    die ($e->getMessage());
}
