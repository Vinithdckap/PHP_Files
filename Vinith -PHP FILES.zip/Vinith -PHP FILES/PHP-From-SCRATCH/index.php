<?php

require 'connection.php';


if(isset($_POST['calculate'])){
    $inputOne = $_POST['firstInput'];
    $operator = $_POST['operator'];
    $inputTwo = $_POST['secondInput'];


    if($operator =="+"){
        $total = $inputOne + $inputTwo;
    }
    if($operator =="-"){
        $total = $inputOne - $inputTwo;
    }
    if($operator =="*"){
        $total = $inputOne * $inputTwo;
    }
    if($operator =="/"){
        $total = $inputOne / $inputTwo;
    }
}

try{
//    $sql = $pdo->prepare("select * from actions");
    $insert = $pdo->prepare("INSERT INTO actions (firstInput,operator,secondInput,total) VALUES('$inputOne','$operator','$inputTwo','$total')");
    $insert->execute();
    header("location: ./show.php");
//    $sql->execute();
//    $users  = $sql->fetchAll($pdo::FETCH_OBJ);
}
catch(PDOException $e){
    die("connection fail");
}

require 'index.html';