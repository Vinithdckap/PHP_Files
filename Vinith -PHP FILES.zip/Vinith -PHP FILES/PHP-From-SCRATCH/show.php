<?php

require 'connection.php';

try {
    $fetch = $pdo->prepare("SELECT * FROM actions");
    $fetch->execute();
    $datas =$fetch->fetchAll(PDO::FETCH_OBJ);
//    header("location: ./list.html");
}
catch (PDOException $e){
    die("connection fail");
}

require 'list.html';