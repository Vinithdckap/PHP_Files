create database project_management_system;

use project_management_system;

create table projects(
    id int not null AUTO_INCREMENT,
    project_name varchar(255),
    primary key (id),
    created_at timestamp,
    updated_at timestamp
 );


create table tasks(
    id int AUTO_INCREMENT,
    project_id int,
    task_name varchar(255),
    task_description varchar(255),
    task_image varchar(255),
    created_at timestamp,
    updated_at timestamp,
    PRIMARY key(id),
    foreign key (project_id) references projects(id)
);