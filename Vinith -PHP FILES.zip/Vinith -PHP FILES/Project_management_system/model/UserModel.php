<?php
    class data
    {
            public $db;
            public function __construct(){
            try {
            $this->db= new PDO
            ("mysql:host=127.0.0.1;dbname=project_management_system",
            "admin",
            "welcome");
            echo  "ello";


    } catch (PDOException $e) {
            die($e->getMessage());
            }
    }
    }
class UserModel extends data {
    // Database connection and other necessary properties

    public function dataInsert($products)
    {

        $products_name =$products['product_name'];


        $this->db ->query( "Insert into products (product_name) values ('$products_name')");
//         header("location:/");
    }
    public function read($id) {

    }

    public function update($products,$files) {




    }

    public function deleteDB($id) {

    }

    public function allproducts() {


    }
}