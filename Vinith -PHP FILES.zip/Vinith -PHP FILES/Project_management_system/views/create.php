<!doctype html>
<html lang="en">
<head>
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@300&family=Playfair+Display:wght@500&display=swap" rel="stylesheet">
    <style>
        body{
            font-family: 'Nunito Sans', sans-serif;
            font-family: 'Playfair Display', serif;
        }
        th{
            background-color: #3e636e;
            color: white;
            font-size:20px;
        }
        td{
            font-size: 18px;
        }
        td:hover{
            background: cadetblue;
            color: white;
        }

        .active{
            font-size: 32px;
            color: black;
        }

        .sidebar {
            position: fixed;
            width: 20%;
            height: 100vh;
            background-color: #3e636e;
            font-size: 0.65em;
        }

        .nav {
            position: relative;
            margin: 0 15%;
            text-align: right;
            top: 50%;
            transform: translateY(-50%);
            font-weight: bold;
        }

        .nav ul {
            list-style: none;
        }
        li {
            position: relative;
            margin: 3.2em 0;

        }
        h1{
            font-size: 26px;
            position: relative;
            bottom: 252px;
            width: 199px;
            right: 20px;
            color: white;
            text-decoration: underline;

        }
        a {
            text-decoration: none;
            font-size: 27px;
            padding-right: 87px;
            position: relative;
            right: 2px;
            bottom: 336px;
            color: white;

        }
        table{
            position: relative;
            left: 374px;
            top: 152px;
            width: 900px;
            font-size: 24px;
            border:none;
        }





    </style>
</head>

<body>
<main class="main">
    <aside class="sidebar">
        <nav class="nav">
            <h1>Lists of Projects</h1>
            <ul>
                <li class="active"><a href="#">Projects</a></li>
            </ul>
        </nav>
    </aside>
</main>

<table border="2" cellpadding="15px">
    <tr>
        <th>S.no</th>
        <th>Project name</th>
        <th>Task name</th>
        <th>Task description</th>
        <th>Task Image</th>
        <th>Delete</th>

    </tr>
        <tr>
            <td>1</td>
            <td>PHP</td>
            <td>MVC PHP</td>
            <td>Model viewer Controller</td>
            <td>
                <img class="image" src="">
            </td>
            <td>
                <button class="delBtn">Delete</button>
            </td>
        </tr>
    <tr>
        <td>2</td>
        <td>Rehan</td>
        <td>Project management system</td>
        <td>Project management system is a system to create projects nd tasks</td>
        <td>
            <img class="image" src="">
        </td>
        <td>
            <button class="delete">Delete</button>
        </td>
    </tr>
    <tr>
        <td>3</td>
        <td>PHP</td>
        <td>Todo</td>
        <td>Todo application</td>
        <td>
            <img class="image" src="">
        </td>
        <td>
            <button class="delete">Delete</button>
        </td>
    </tr>

</table>
</body>
</html>