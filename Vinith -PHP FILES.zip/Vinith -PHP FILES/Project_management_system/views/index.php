<!doctype html>
<html lang="en">
<head>
    <title>Document</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@300&family=Playfair+Display:wght@500&display=swap" rel="stylesheet">

    <style>
       body{
           font-family: 'Nunito Sans', sans-serif;
           font-family: 'Playfair Display', serif;
       }


        input[type=text], select {
            width: 30%;
            padding: 12px 20px;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            margin-left: 550px;
            margin-top: 90px;
        }
        label {
            padding-left: 354px;
            position: relative;
            top: 127px;
            font-size: 32px;
        }

        input[type=text], select {
            width: 30%;
            padding: 12px 20px;
            display: inline-block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            margin-left: 550px;
            margin-top: 90px;
        }
        label {

            position: relative;
            top: 127px;
            font-size: 32px;")
            font-weight: bold;
            color: #3e636e;
        }
        button{
            width: 10%;
            background-color: #3e636e;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            position: relative;
            left: 987px;
            bottom: 51px;
            font-size: 16px;
            font-family: 'Nunito Sans', sans-serif;
            font-family: 'Playfair Display', serif;
        }

       .active{
           font-size: 32px;
           color: black;
       }
        .sidebar {
            position: fixed;
            width: 20%;
            height: 100vh;
            background-color: #3e636e;
            font-size: 0.65em;
        }
        .nav {
            position: relative;
            margin: 0 15%;
            text-align: right;
            top: 50%;
            transform: translateY(-50%);
            font-weight: bold;
        }
        .nav ul {
            list-style: none;
        }
        li {
            position: relative;
            margin: 3.2em 0;

        }
        h1{
            font-size: 26px;
            position: relative;
            bottom: 252px;
            font-style: italic;
            width: 199px;
            right: 20px;
            color: white;
            text-decoration: underline;

        }
        a {
            text-decoration: none;
            color: white;
            font-size: 27px;
            padding-right: 87px;
            position: relative;
            right: 2px;
            bottom: 336px;
        }
    </style>
</head>

<body>
<main class="main">
    <aside class="sidebar">
        <nav class="nav">
            <h1>Lists of Projects</h1>
            <ul>
                <li class="active"><a href="task.php">Projects</a></li>
            </ul>
        </nav>
    </aside>

</main>

    <form action="" method="post">
        <label for="project_name">Project name</label><br>
        <input type="text" id="project_name" name="project_name"><br>
    </form>
    <button type="submit">Create</button>

</body>
</html>