<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<form action="/create" method="post">
    <div class="container">
        <input type="text" placeholder="project name" name="project_name" required>
        <button type="submit"  value="create" name="action">register</button>
    </div>
</form>
</body>
</html>