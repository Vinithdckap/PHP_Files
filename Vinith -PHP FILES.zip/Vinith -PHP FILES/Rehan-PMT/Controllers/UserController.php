<?php
require "Model/UserModel.php";
unset($_SESSION['getId']);
class UserController{
    public $model;
    public function __construct()
    {
        $this->model= new UserModel();
    }
    public function view(){
//        session_unset($_SESSION['getId'] );

        $view = $this->model->view();
        require "views/home.php";
    }

    public function getTask($getId){
        $_SESSION['getId'] = $getId;
        $view = $this->model->view();
        $projectId=$getId['project_id'];
        require 'views/home.php';
    }
    public  function addTask($tasks){
        $this->model->addTask($tasks);
    }

    public  function showTask(){
        $task = $this->model->showTask();
    }

    public function insertFunction($getData){
        $id = $getData['tarId'];
        require 'views/task.php';
    }

    public  function create($data){
        if($data){
            $this->model->createProject($data);
//            var_dump($data);
            header("location:/");

        }
        else{
            require "views/create.php";

        }
    }


}