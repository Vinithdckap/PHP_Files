<?php
class data
{
    public $db;
    public function __construct(){
        try {
            $this->db= new PDO
            ("mysql:host=127.0.0.1;dbname=pmt",
                "admin",
                "welcome");


        } catch (PDOException $e) {
            die($e->getMessage());
        }
    }
}
class UserModel extends data {
    // Database connection and other necessary properties

    public function createProject($products)
    {
        $project_name =$products['project_name'];
        $this->db ->query( "Insert into projects (project_name) values ('$project_name')");
//         header("location:/");
    }

    public function view() {
        $list=$this->db->query("select * from projects");
        $list->execute();
        $all =$list->fetchAll(PDO::FETCH_OBJ);
        return $all;
    }
    public function addTask($tasks){
        $task_name =$tasks['task_name'];
        $task_description =$tasks['task_description'];
        $taskId = $tasks['id'];
        $this->db->query("insert into tasks (task_name,task_description,projects_id)values ('$task_name','$task_description','$taskId')");
        header("location:/");
    }
    public function showTask(){

        $show = $this->db->query("select * from tasks ");
        $show->execute();
        $task = $show->fetchAll(PDO::FETCH_OBJ);
        return $task;

    }


    public function getTask($id){

        $data = $this->db->query("SELECT * FROM tasks WHERE id = '$id'");
        return $data->fetchAll(PDO::FETCH_OBJ);
    }
}