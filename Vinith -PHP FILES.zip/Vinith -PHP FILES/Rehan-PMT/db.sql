create database pmt;

use pmt;

create table projects(
    id int AUTO_INCREMENT,
    project_name varchar(255),
    created_at timestamp,
    updated_at timestamp,
    primary key(id)
    );

    create table tasks(
    id int AUTO_INCREMENT,
    task_name varchar(255),
    task_description varchar(255),
    file varchar(255),
    projects_id int,
    deleted_at timestamp  null,
    created_at timestamp,
    updated_at timestamp,
    primary key (id),
    FOREIGN key (projects_id) REFERENCES projects(id)
    );