<?php
require "core/router.php";
session_start();
$router = new router();

$router->get('/',"list");
$router->post('/create',"create");
$router->post('/getTask','getTask');
$router->post('/addTask','addTask');
$router->get('/insertTask','insertTask');

$router->routing();
