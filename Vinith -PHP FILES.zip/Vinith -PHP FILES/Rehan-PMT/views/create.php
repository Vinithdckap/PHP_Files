<!doctype html>
<html lang="en">
<head>
    <title>Document</title>
</head>
<body>

<form action="/create" method="post">
    <div class="container">
        <input type="text" placeholder="project name" name="project_name" required>
        <button type="submit"  value="create" name="action">Add project</button>
    </div>
</form>

</body>
</html>