<!doctype html>
<html lang="en">
<head>
    <title>Document</title>
</head>
<body>
        <form action="/create" method="post">
            <div class="container">
                <button type="submit" >Create project</button>
            </div>
        </form>
        <table>
            <tr>
                <th>All projects</th>
            </tr>
            <?php foreach ($view as $index => $views):?>
            <form action="/getTask" method="post">
                <tr>
                    <td>
                        <button name ="project_id" value="<?php echo $views->id?>" name="tarId"><?php echo $views->project_name ?></button>
                    </td>
                </tr>
            </form>
            <?php endforeach; ?>

            <br>
        </table>
        <?php if (isset( $_SESSION['getId'] )):?>
        <form action="/insertTask" method="post">
            <?php foreach ($task as $index => $viewTask):?>

                <table border="2" cellpadding="15px">
                <tr>
                    <th>S.no</th>
                    <th>Task name</th>
                    <th>Task description</th>
                    <th>Task Image</th>
                    <th>Delete</th>

                </tr>
                <tr>
                    <td><?php echo $viewTask->id ?></td>
                    <td><?php echo $viewTask->task_name?></td>
                    <td><?php echo  $viewTask->task_description?></td>
                    <td>
                        <img class="image" src="">
                    </td>
                    <td>
                        <button class="delBtn">Delete</button>
                    </td>
                </tr>
            </table>
<?php endforeach; ?>

            <button value="<?php echo $projectId ?>" name="tarId">create task</button>
        </form>
        <?php endif;?>
</body>
</html>