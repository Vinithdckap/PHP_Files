<!DOCTYPE html>
<html lang="en">
<head>
    <title> Products</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@300&family=Playfair+Display:wght@500&display=swap" rel="stylesheet">

    <style>
        body{

            overflow-x: hidden;
            overflow-y: hidden;
            font-family: 'Nunito Sans', sans-serif;
            font-family: 'Playfair Display', serif;
        }

        form{
            display: grid;
            position: relative;
            left: 551px;
            bottom: 37px;

        }
        input::placeholder{
            font-family: 'Nunito Sans', sans-serif;
            font-family: 'Playfair Display', serif;
        }
        label{
            font-weight: 500;
            width: 220px;
            position: relative;
            top: 76px;
            font-size: 19px;

        }

        h1 {
            position: relative;
            color:#3e636e;
            top: 65px;
            left:29px;
            font-size: 33px;
        }

        input[type=text], input[type=file] {
            width: 20%;
            padding: 10px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
            border-radius: 10px;
            position: relative;
            top: 75px;
            font-family: 'Nunito Sans', sans-serif;
            font-family: 'Playfair Display', serif;


        }

        .btn {
            background-color:#3e636e;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 10%;
            border-radius: 10px;
            position: relative;
            left:50px;
            top: 82px;
            font-family: 'Nunito Sans', sans-serif;
            font-family: 'Playfair Display', serif;
        }


    </style>
</head>
<body>

<div class="container">
    <form action="/addTask" method="post"  enctype="multipart/form-data">

        <h1>Create Tasks</h1>

        <label for="">Task Name</label>
        <input  type="text" name="task_name"  placeholder="Add tasks">

        <label for="">Task Description</label>
        <input type="text" name="task_description" placeholder="task description">

        <label for="">Add task Image</label>
        <input type="file" name="image" placeholder ="task image" width="75px" height ="75px">
        <input type="text" hidden value="<?php echo $id ?>"  name="id"/>
        <input type="submit"  class="btn" name="create"  value="Add your task">

    </form>


</div>
</body>
</html>

