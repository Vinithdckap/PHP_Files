 <?php
 try{
    $pdo = new PDO("mysql:host=localhost;dbname=tasks","admin","welcome");
   //  echo "hello world";
 }
 catch(PDOException $e){
    die ($e->getMessage());
 }
 $name = $_POST['name'];
 $id =  $_POST["id"];
 $status = $_POST["is_completed"];
  try{
   $sql = $pdo->prepare("select * from users");
   $insert  = $pdo->prepare("INSERT INTO users(id,task_name,is_completed) VALUES('$id','$name','$status')");
  

   $insert->execute();
   $sql->execute();
   $users  = $sql->fetchAll($pdo::FETCH_OBJ);
 }
 catch(PDOException $e){
    die("connection fail");

 }

 require 'index.html';


?>



 
