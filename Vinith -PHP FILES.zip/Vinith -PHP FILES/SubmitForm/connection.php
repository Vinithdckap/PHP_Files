<?php

try{
    $pdo = new PDO("mysql:host=localhost;dbname=submitForm","admin","welcome");

}
catch(PDOException $e){
    die ($e->getMessage());
}


