<?php
require 'connection.php';

$delete=$_POST['delete'];

try {
    $del =$pdo->query("DELETE from form where form.id = $delete");
    $del -> execute();
    header('location:./fetch.php');


}
catch (PDOException $e) {
    die ("connection error");


}

