<?php
require "connection.php";

//getting value from edit html
$edit=$_POST['edit'];
// echo $edit;


try {
    // inserting into database
    $query =$pdo->prepare("SELECT * FROM form where id = '$edit'");
    $query->execute();
    //fetching all datas
    $editing = $query->fetchAll(PDO::FETCH_OBJ);

}
catch ( PDOException $e) {
    die ("connection error");
}

require "edit.html";

