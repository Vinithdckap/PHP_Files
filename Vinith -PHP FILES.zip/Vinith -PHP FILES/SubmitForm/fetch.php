<?php

require "connection.php";

try {
    $query =$pdo->prepare("SELECT * FROM form");
    $query -> execute();

    $tasks = $query->fetchAll(PDO::FETCH_OBJ);
    // var_dump($query->fetchAll(PDO::FETCH_OBJ));
}
catch(PDOException $e){
    die ($e->getMessage());
}
require 'data.html';


