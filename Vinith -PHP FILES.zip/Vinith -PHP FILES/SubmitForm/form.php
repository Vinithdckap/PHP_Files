<?php

require "connection.php";

try {
    // inserting into database

    $name = $_POST['firstName'];
    $lastName = $_POST['lastName'];
    $email = $_POST['email'];
    $website =  $_POST['website'];
    $address = $_POST['address'];
    $gender = $_POST['gender'];

    $sql=  $pdo->prepare("INSERT INTO form (name,lastName,email,website,gender,address) VALUES('$name', '$lastName', '$email','$website','$gender','$address')");

    $sql->execute();
    header("location: ./fetch.php");

}
catch (Exception $e) {
    // it will die the code here when not connected
    die("connection error".$e->getmessage());

}

require 'index.html';




?>


