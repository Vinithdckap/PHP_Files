<?php
require "connection.php";
$id = $_POST['updateid'];
$edit_name = $_POST['edit_firstName'];
$edit_lastName = $_POST['edit_lastName'];
$edit_email = $_POST['edit_email'];
$edit_website =  $_POST['edit_website'];
$edit_address = $_POST['edit_address'];


try {
    $update_data = $pdo->prepare("UPDATE form SET name='$edit_name',lastName='$edit_lastName',email='$edit_email',website='$edit_website',address='$edit_address' where id = '$id'");
    $update_data->execute();
    // print_r($update_data);
//    echo "updated";
    header('location:/fetch.php');

} catch (PDOException $e) {
    die($e->getMessage());
}

require 'edit.html';