<?php
class dbconnection
{
    public $db;

    public function __construct()
    {
        try {
            $this->db = new PDO(
                'mysql:host=localhost;dbname=login',
                'admin',
                'welcome'
            );
        }
        catch (PDOException $e){
            echo "connection failed";
        }
    }
    public function query($executeQuery){
        $statement = $this->db->prepare($executeQuery);
        $statement->execute($statement);

        return $statement;
    }
}