<?php
if(!isset($_SESSION['login'])){
    header("location:/");
}


require 'viewers/home.view.php';