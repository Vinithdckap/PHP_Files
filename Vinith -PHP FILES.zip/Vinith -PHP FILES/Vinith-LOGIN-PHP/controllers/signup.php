
<?php


$email = $_POST['email'];
$password = $_POST['password'];

if ($email =="" && $password ==""){
    header('/');
}else{

    if($email && $password){

        $statement = $app['db']->query("select * FROM details WHERE email ='$email' and password= md5('$password')");
        $result = $statement->fetchAll();
    var_dump($result);

//
        if ($result) {
            $_SESSION['login'] = [
                'email' => $email
            ];
            header('location:/home');
        } else {
            $_SESSION['error'] = "Invalid email or password";
            header("location:/loginPage");
        }
    }
}



//}








