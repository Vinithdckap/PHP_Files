<?php
$app = [];

require 'connection.php';
session_start();
$app['db'] = (new dbconnection()) -> db;

$routers = [
    '/' => 'controllers/signupview.php',
    '/loginPage'=>'viewers/login.view.php',
    '/signup' => 'controllers/signup.php',
    '/home' => 'controllers/home.php',
    '/login' => 'controllers/login.logic.php',
    '/logout'=>'controllers/logout.php'
];

if(array_key_exists($_SERVER['REQUEST_URI'],$routers)){
    require $routers[$_SERVER['REQUEST_URI']];
}
else{
    http_response_code (404);
    require 'viewers/error/error.php';
}

