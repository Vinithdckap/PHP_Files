<!DOCTYPE html>
<html lang="en">
<head>
    <title>Login</title>
    <link rel="stylesheet" href="../style.css"/>

</head>
<body>

<div class="login-box">
    <h1>Login</h1>
    <form action="/login" method="post">
        <label>Email</label>
        <input type="email" placeholder="" name="email"/>
        <label>Password</label>
        <input type="password" placeholder="" name="password"/>
        <button class="btn" name="submit">Submit</button class="btn" name="submit">

        </form>
</div>
<p class="para-2">
    Not have an account? <a href="/signup">Sign Up Here</a>
</p>
</body>
</html>
