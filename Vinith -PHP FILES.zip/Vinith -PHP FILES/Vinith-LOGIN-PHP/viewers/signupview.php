
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Sign Up</title>
    <link rel="stylesheet" href="../style.css" />

</head>
<body>
<div class="login-box">
    <h1>Admin login</h1>
    <form action="/signup" method="post">
        <label>Email</label>
        <input type="email" placeholder="" name="email"/>
        <label>Password</label>
        <input type="password" placeholder="" name="password"/>
        <button class="btn" name="submit">Submit</button class="btn" name="submit">

    </form>
</div>
<p class="para-2">
    Already have an account? <a href="/loginPage">Login here</a>
</p>
</body>
</html>
