<?php
require "models/UserModel.php";
class UserController {
    private $userModel;

    public function __construct() {
        $this->userModel = new UserModel();
    }

    public function create($user) {
        print_r($user);
        $this->userModel->Inserting_to_db($user['username'],$user['email']);

    }

    public function edit($id) {

        $edit =  $this->userModel->read($id);

        require "views/user/edit.php";
        // Handle form submission for updating an existing user
    }

    public function delete($id) {

        $this->userModel->delete($id);
        header("location:/");

    }

    public function index() {

       $alluser= $this->userModel->getAllUsers();
       require "views/user/index.php";
        // Retrieve all users from the UserModel and load the index view
        
    }

    public function view($editData) {

    }
    public function update($editData) {

        $this->userModel->update($editData);
    }
}
