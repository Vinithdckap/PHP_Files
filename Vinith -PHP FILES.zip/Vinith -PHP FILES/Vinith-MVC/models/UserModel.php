<?php

class database
{
    public $db;
    public function __construct()
    {
        try {
            $this->db= new PDO
            ("mysql:host=localhost;dbname=mvc","admin","welcome");
//             echo "ok";
        }
        catch (PDOException $e) {
            die($e->getMessage());
        }
    }


}


class UserModel extends  database {
    // Database connection and other necessary properties

    public function Inserting_to_db($name,$email) {

        
        $this->db->query("Insert into users (username,email) values ('$name','$email')");
        header("location: /");
        // Perform database insert operation using $data
    }

    public function read($id) {
        // Perform database select operation based on $id

        $statement = $this->db->query("select * from users where id = '$id'");
        $data = $statement->fetchAll(PDO::FETCH_OBJ);
        return $data;

    }

    public function update($id) {

        $username = $id["userName"];
        $email =$id["email"];
        $updatedId = $id["update"];

        // Perform database update operation based on $id and $data
        $this->db->query("update users set username='$username',email='$email' where id ='$updatedId'");
        header("location:/");
    }

    public function delete($id) {

        $this->db->query("DELETE FROM users where id ='$id'");

        // Perform database delete operation based on $id
    }

    public function getAllUsers() {

    $statement = $this->db->query("select * from users");
    $statement->execute();
    $data = $statement->fetchAll(PDO::FETCH_OBJ);
    return $data;




        // Retrieve all users from the database
    }
}