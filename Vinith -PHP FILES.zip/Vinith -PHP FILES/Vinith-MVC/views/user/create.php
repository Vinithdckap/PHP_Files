<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="style.css">
</head>


<body>


<form action="../../index.php" method="post">


  <div class="container">
    <input type="text" placeholder="Enter Username" name="username" required>
    <input type="z" placeholder="Enter email" name="email" required>
    <button type="submit"  value="create" name="action">create</button>
  </div>


</form>



</body>
</html>

