<!doctype html>
<html lang="en">
<head>
    <title>Document</title>
    <style>


        form{
            padding: 16px;
            margin-top: 56px;
            margin-left: 420px;
        }

        input[type=text], input[type=email] {
            width: 20%;
            padding: 12px 20px;
            margin: 8px 0;
            display: inline-block;
            border: 1px solid #ccc;
            box-sizing: border-box;
            border-radius: 10px;
        }

        button {
            background-color:crimson;
            color: white;
            padding: 14px 20px;
            margin: 8px 0;
            border: none;
            cursor: pointer;
            width: 20%;
            border-radius: 10px;
        }

    </style>
</head>
<body>
<?php foreach ($edit as $datas):?>
<form action="index.php" method="post">
    <input type="text" name="userName" value="<?php echo $datas->username?>">
    <input type="text" name="email" value="<?php echo $datas->email?>">
    <input type="hidden" name="update" value="<?php echo $datas->id?>">
    <button type="submit" name="action" value="update" >Update</button>
</form>
<?php endforeach;?>


</body>
</html>
