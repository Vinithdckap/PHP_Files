<!doctype html>
<html lang="en">

<head>
    <style>
        body {
            font-style: italic;
        }
        table {
            border-collapse: collapse;
            width: 53%;
            height: 186px;
            position: relative;
            left: 350px;
            top: 49px;
        }
        }

        th, td {
            padding: 8px;
            border-bottom: 1px solid #ddd;
        }

        .create{
            font-size: 24px;
            font-weight: bold;
            text-decoration: none;
            position: relative;
            left: 600px;
            top: 39px;
            color: black;
]
        }

        td {
            text-align: center;

        button{

            background-color: #e3e9dd;
            border: none;
            border-radius: 8px;
            height: 26px;
            width: 62px;

        }

        }

    </style>

</head>
<body>
    <a href="views/user/create.php" class="create">Create new user + </a><br>


<table border="2" >
    <tr>
        <th>Username</th>
        <th>Email</th>
        <th>Edit</th>
        <th>Delete</th>

    </tr>
    <?php foreach ($alluser as $allusers): ?> <br>

        <tr>
            <td><?php echo $allusers->username ?></td>
            <td><?php echo $allusers->email  ?></td>
            <td>
                <form action="../../index.php" method="post">
                    <input type="hidden" name="edit"  value="<?php echo $allusers->id?>" >
                    <button type="submit" name="action" value="edit" >Edit</button>
                </form>
            </td>
            <td>
                <form action="../../index.php" method="post">
                    <input type="hidden" name="delete" value="<?php echo $allusers->id?>">
                    <button type="submit" name="action" value="delete" >Delete</button>
                </form>
            </td>
        </tr>




    <?php endforeach; ?>

</table>

</body>
</html>