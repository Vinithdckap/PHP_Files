<?php

// class name{

    // public function add ($number1,$number2)
    // {
    //   return $number1 + $number2."\n";
    // }
//   }

//   $dbms = new name();
//   echo $dbms->add(7,6)

// $who = 'vinith';
// $mail = 'vinithkdckap@gmail.com';

// echo $name . $mail;


// $name = 'vinith';
// echo ' hey my name is' . $name

// echo "hey my name is $name"

//  echo "php is a server side language \"yeah\"";
//  echo 'php is a server side language "yeah"';

// echo $name[3];


//  echo strtolower($name);
// echo strtoupper($name)
// echo str_replace('v','w',$name)


// class organisation
// {
//     public $company;
//     public $position;
//     public function setcompany($company)
//     {
//         $this -> company = $company;

//     }
//     public function setpositon ($position)
//     {
//         $this -> position = $position;
//     }

// }
// class employee extends organisation
// {
//     public $name;
//     public $date_of_join;
//     public function setname($name)
//     {
//         $this -> name = $name;
//     }
//     public function setdate($date_of_join){

//         $this -> date_of_join = $date_of_join;
//     }
//     public function getinfo()
//     {
//         echo $this-> name."\n";
//         echo $this-> company."\n";
//         echo $this-> position."\n";
//         echo $this-> date_of_join."\n";

//     }
    
// }

//   $class = new employee();
//   $class-> setcompany("Dckap");
//   $class-> setpositon("01");
//   $class-> setname("Vinith");
//   $class-> setdate("12/09/2022");
//   $class-> getinfo();

//   echo "\n";
//   $class = new employee();
//   $class-> setcompany("Dckap");
//   $class-> setpositon("01");
//   $class-> setname("ganeg");
//   $class-> setdate("12/09/2022");
//   $class-> getinfo();



abstract class Organization
{
    abstract public function promotion();
    abstract public function qualification();
    
}

class Student extends Organization
{
    public $doj;
    public $reason;

    public function setDoj ($doj)
    {
        $this-> doj = $doj;
    }
    public function promotion()
    {
      echo "No promotion";
    }
    public function setReason($reason)
    {
        $this->reason = $reason;
    }
    public function qualification()
    {
        echo "You're not eligible to promote";
    }

}
class Employee extends Organization
{
    public $doj;
    public $reason;

    public function setDoj ($doj)
    {
        $this-> doj = $doj;
    }
    public function promotion()
    {
        
         if ($this->doj<1){
            echo "No promotion";

        }
        else if ($this->doj>1 && $this->doj<5) {
            echo "Give promotion";
        }

        else {
            echo "No promotion";
        }
    }
    public function setReason($reason)
    {
        $this->reason = $reason;
    }

    public function qualification()
    {
        echo "Congratulation on your promotion";
    }



}


class Staff extends Organization
{
    public $doj;
    public $reason;

    public function setDoj ($doj)
    {
        $this-> doj = $doj;
    }
    public function promotion()
    {
      echo "No promotion";
    }
    public function setReason($reason)
    {
        $this->reason = $reason;
    }
    public function qualification()
    {
        echo "You're not eligible to promote";
    }


}

 
$Student = new Student();
$Student ->setDoj(2);
$Student ->promotion();
echo "\n";
$Student ->setReason(2);
$Student->qualification();


echo "\n";


$Employee = new Employee();
$Employee ->setDoj(4);
$Employee ->promotion();
echo "\n";
$Employee ->setReason(2);
$Employee->qualification();

echo "\n";


$Staff = new Staff();
$Staff ->setDoj(2);
$Staff ->promotion();
echo "\n";
$Staff ->setReason(2);
$Staff->qualification();


class validation
{
    public $a;
    public $b;
    
    public function __construct($a,$b)
    {
        $this->a = $a;
        $this->b =$b;
    }
    public function validate()
    {
        return (is_int($this->a)&& is_int($this->b));
    }

}
class calculator extends validation

{
    public function add ():int|string
    {
        if($this -> validate()){
            return $this -> a + $this->b;
        }
        return "Please input correct value";
    }
    public function sub():int|string
    {
        if($this-> validate()){
            return $this-> a  - $this->b;
        }
    }
    public function mul():int|string
    {
      if ($this-> validate()){
        return $this-> a * $this-> b;
      }
    }
}

$calculator = new calculator(2,3);

echo $calculator-> add();
// echo "\n";
// $calculator = new calculator(2,3);
// echo $calculator-> sub();
// echo "\n";

// $calculator = new calculator(35,35);
// echo $calculator-> mul();





abstract class B
{
    public $a = 10;

    abstract public function bone();

    public function btwo()
    {
        echo "running b2";
    }
}

interface C
{
    public function cone();
}

class A extends B implements C
{
    public function __construct()
    {
        $this->bone();
        echo "\n";
        $this->btwo();
        echo "\n";
        $this->cone();
        echo "\n";
        echo $this->a;
    }

    public function bone()
    {
        echo "running b1";
    }

    public function cone()
    {
        echo "running c1";
    }
}


(new A);
echo "\n";


function game($name){
    echo "the game name is $name ";
}
game("cricket");echo "\n";
game("football");echo "\n";
game("kabaddi");echo "\n";


function edit($a){
    $a = "photographer";
}
$b = "pg";
edit($b);
echo $b;


$a = array("welcome","to","dckap");
echo $a[2];

echo "\n";
$marks["Vinu"]= 98;
$marks["Minnu"]= 97;
$marks["Meow"] = 99;
echo "the marks obtained by  is".$marks["Vinu"];

$array = array(array("vinith","vinu","minnu"),array("qwe","edfv","av"));

print_r($array);
echo "\n";

$edtech = "learn php";
function student(){
    global $edtech;
    echo "to learn php".$edtech;

}
student();

echo "hey you".$edtech;

echo "\n";

function students(){
    static $marks = 86;
    $marks++;
    echo "the mark of the student is".$marks;
}
students();
echo "\n";
students();
echo "\n";
students();
echo "\n";
students();
echo "\n";

function marks(){
    $student = "vinith";
    echo "hey you".$student;
}
marks();
echo $student;


?>






