<?php

class db{
    public $dbConnect;
    public function __construct()
    {
        $this->dbConnect = new PDO('mysql:host=localhost;dbname=project_management','admin','welcome');
    }
}
class UserController extends db{

    public function insertProject($getProject){
        $this->dbConnect->query("INSERT INTO projects(project_name) values ('$getProject')");
        $id = $this->dbConnect->query("select id from projects order by id desc limit 1");
        $count = $id->fetch(PDO::FETCH_NUM);
        return $count[0];

    }

}