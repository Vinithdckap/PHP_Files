<?php
require 'core/router.php';
session_start();
$router = new router();
unset($_SESSION['projectPage']);
// calling router function


$router->get('/','allProjects');


$router->routingFunc();