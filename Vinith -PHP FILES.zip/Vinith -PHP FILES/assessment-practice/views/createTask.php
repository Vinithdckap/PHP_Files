<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>create task</title>
</head>
<body>
<div class="container">
    <form action="/createProject" method="post" enctype="multipart/form-data">
        <input type="text" name="project_name">
        <input type="file" multiple="multiple" name="projectImg[]">
        <button type="submit"></button>
    </form>
</div>


</body>
</html>