<<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
 <div class="container">
     <?php if ($_SESSION['projectPage']): ?>
     <?php require 'views/createTask.php' ?>
     <?php else: ?>
     <div class="addProject">
         <form action="/createProject" method="post">
             <button type="submit" class="projectBtn">Add project</button>
         </form>
     </div>
     <?php endif;?>
 </div>

</body>
</html>