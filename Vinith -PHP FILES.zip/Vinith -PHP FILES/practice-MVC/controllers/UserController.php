<?php
require "models/UserModel.php";
class UserController {
    private $userModel;

    public function __construct() {
        $this->userModel = new UserModel();
    }

    public function create($user) {

        $this->userModel->Inserting_to_db($user);
        header('location: /');

    }

    public function edit($id) {
      $edit =  $this->userModel->read($id);

        require "views/user/edit.php";




    }

    public function delete($id) {


        $this->userModel->delete($id);

    }
    public function index() {


      $allusers =  $this->userModel->getAllUsers();
        require "views/user/index.php";
        // Retrieve all users from the UserModel and load the index view

        header("location: /");
    }
    public function update($editData) {

        $this->userModel->update($editData);

    }
}
