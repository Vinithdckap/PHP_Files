create database practicemMVC;

use practiceMVC;

create table users(
    id int AUTO_INCREMENT null,
    name varchar(255),
    email varchar(255),
    password varchar(255),
    PRIMARY key (id),
    created_at timestamp,
    updated_at timestamp
    );
