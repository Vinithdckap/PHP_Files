<?php

class database
{
    public $db;
    public function __construct()
    {
        try {
            $this->db= new PDO
            ("mysql:host=localhost;dbname=practicemMVC","admin","welcome");
//            echo  "hello world";

        }
        catch (PDOException $e) {
            die($e->getMessage("no db found"));
        }
    }


}


class UserModel extends  database {
    // Database connection and other necessary properties

    public function Inserting_to_db($user) {

        $name = $user["userName"];
        $email = $user["email"];
        $password =$user["password"];

        $this->db->query("INSERT INTO users(userName,email,password) values('$name','$email',MD5('$password'))");
    }

    public function read($id) {
        // Perform database select operation based on $id
        $statement = $this->db->query("select *from users where id ='$id'");
        $editData = $statement->fetchAll(PDO::FETCH_OBJ);
        return $editData;





    }

    public function update($id) {


        $username = $id["userName"];
        $email =$id["email"];
        $password =$id['password'];
        $updatedId = $id["update"];

        // Perform database update operation based on $id and $data
        $this->db->query("update users set username='$username',email='$email',password='$password' where id ='$updatedId'");
        header("location:/");


    }

    public function delete($id) {

        $statement = $this->db->query("select * from users where id ='$id'");



    }

    public function getAllUsers() {

        $statement = $this->db->query("select * from users");
        $statement->execute();
        $data = $statement->fetchAll(PDO::FETCH_OBJ);
        return $data;





        // Retrieve all users from the database
    }
}