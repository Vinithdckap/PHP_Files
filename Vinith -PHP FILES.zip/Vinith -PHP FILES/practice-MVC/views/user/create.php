<!doctype html>
<html lang="en">
<head>

    <title>Document</title>
</head>
<body>

<form action="../../index.php" method="post">
    <input type="text" name="userName" placeholder="enter name">
    <input type="email" name="email" placeholder="enter email">
    <input type="password" name="password" placeholder="enter password">
    <button type="submit" name="action" value="create">Create</button>

</form>

</body>
</html>