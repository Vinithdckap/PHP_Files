<!doctype html>
<html lang="en"
<head>
    <title>Document</title>
</head>
<body>

<?php foreach ( $edit as $editData):?>

<form action="index.php" method="post">
    <input type="text" name="userName" placeholder="enter name" value="<?php echo $editData->userName?>">
    <input type="email" name="email" placeholder="enter email" value="<?php echo $editData->email?>">
    <input type="password" name="password" placeholder="enter password" value="<?php echo $editData->password?>" >
    <input type="hidden" name="update" value="<?php echo $editData->id?>">
    <button type="submit" name="action" value="update">Update</button>
    </form>
<?php endforeach;?>



</body>
</html>