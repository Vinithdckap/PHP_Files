<!doctype html>
<html lang="en">
<head>

    <title>Fetch</title>
</head>
<body>

    <a href="views/user/create.php" class="create">Create new user + </a><br>

    <table border="2" >
        <tr>
            <th>Username</th>
            <th>Email</th>
            <th>Password</th>
            <th>Edit</th>
            <th>Delete</th>


        </tr>
    </table>

<?php foreach ($allusers as $alluser): ?>
        <tr>
            <th><?php echo $alluser->userName ?></th>
            <th><?php echo $alluser->email ?></th>
            <th><?php echo $alluser->password ?></th>

         <form action="../../index.php" method="post">
             <input type="hidden" name="edit" value="<?php echo $alluser->id?>">
             <button type="submit"  name="action" value="edit" >Edit</button>
         </form>

            <form action="../../index.php" method="post">
                <input type="hidden" name="delete" value="<?php echo $alluser->id?>">
                <button type="submit"  name="action" value="delete" >Delete</button>
            </form>







        </tr>

<?php endforeach; ?>

</body>
</html>
