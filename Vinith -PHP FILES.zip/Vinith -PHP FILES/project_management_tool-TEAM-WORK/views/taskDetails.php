<html>
    <head>
        <title>task details</title>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Nunito+Sans:wght@300&family=Playfair+Display:wght@500&display=swap" rel="stylesheet">
    </head>
<body>
    <div class="main">
        <h2>Task Details</h2>
        <?php foreach ($particularTask as $task_details ): ?>
<!--        --><?php //print_r($task_details)?>

        <h2><?php echo $task_details->tasks_name?></h2>
        <p><?php echo  $task_details->tasks_description?></p>
        <form action="/delete-task" method="post">
            <input type="hidden" name="delete-id" value="<?php echo $task_details->id?>">
            <button type="submit">delete task</button>
        </form>
        <?php endforeach;?>
    </div>
    <div class="imgs">
        <?php foreach($datas as $data=> $value): ?>

        <img src="<?php echo $value->images_path ?>" style="height: 100px" width="100px" />
        <?php endforeach; ?>
    </div>
</body>
</html>